<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'quanlytuyendungabc');

define('BASE_URL', 'http://localhost/Project/web/public/index.php');

// Cấu hình SMTP (tạm thời dùng Gmail làm ví dụ)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'nguyenhuukhang999999999@gmail.com');          // Gmail của bạn
define('SMTP_PASS', 'ybyb ksqn plcq fdnz');             // App password của Gmail
define('SMTP_FROM_EMAIL', 'jobmatch@gmail.com');    // Email From
define('SMTP_FROM_NAME', 'Công ty săn đầu người ABC');
?>